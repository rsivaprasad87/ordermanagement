import json
import boto3
import datetime
import os
import logging

sqs = boto3.client('sqs')

# Initialize the logger
logger = logging.getLogger()
logger.setLevel("INFO")

def lambda_handler(event, context):
    # TODO implement
    # bucket_name = os.environ.get('RECEIPT_BUCKET')
    QUEUE_URL = os.environ.get('SQS_QUEUE_URL')
    try:
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            time = record['eventTime']
            logger.info(f"Event received: {json.dumps(event)} from bucket {bucket}")

            message = {
                "bucket": bucket,
                "file": key,
                "uploaded_at": time
            }

            response = sqs.send_message(
                QueueUrl=QUEUE_URL,
                MessageBody=json.dumps(message)
            )

            logger.info(f"SQS Message Sent: {response['MessageId']}")

        return {
            'statusCode': 200,
            'body': 'Message sent to SQS'
        }
    except Exception as e:
        logger.error(f"Error processing order: {str(e)}")
        raise